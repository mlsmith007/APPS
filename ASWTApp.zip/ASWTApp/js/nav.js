﻿$(document).ready(function () {
    $('#server_link').click(function () {
        // $('#js-page-content').load('lookupforms/servers/servers.html')
        $('#main_server').removeAttr('hidden');
        $(document).on('click', '#server_search_btn', function () {
            ServerLookupCMDBTab();
            ADGroupsLookupADGroupsTab();
        });
    });
    $('#service_accounts_link').click(function () {
        $('#js-page-content').load('lookupforms/servers/servers.html')
    });
    $('#ad_group_link').click(function () {
        $('#js-page-content').load('lookupforms/servers/servers.html')
    });
    $('#users_accounts_link').click(function () {
        $('#js-page-content').load('lookupforms/servers/servers.html')
    })
});