﻿function ServerLookupCMDBTab() {
    // First query to see if the server object exists in the SQL Database
    // var url = "http://127.0.0.1:8000/Get-CMDBServerInfo/${servername}"

    // need to pull the server name from the search box
    var url = "http://127.0.0.1:8000/Get-CMDBServerInfo/" + $('#server_search_text').val();
    $.ajax({
        url: url
    }).then(function (data) {
        var jsonresult = JSON.parse(data);
        // console.log(jsonresult);
        if (jsonresult !== "Nothing returned") {
            // console.log("We have results");
            // Add the results form
            // $('#tab_cmdb').load('lookupforms/servers/cmdb_table.html');
            // Unhide the results section
            $('#server_search_result').removeAttr('hidden');
            $('#cmdb_table').removeAttr('hidden');
            // console.log("Populating 'OS' field with:" + jsonresult.fqdn);

            // Populate the fields
            // console.log("Populating 'OS' field with:" + jsonresult.fqdn);
            $('#cmdb_fqdn').val(jsonresult.fqdn);
            $('#cmdb_ipaddress').val(jsonresult.IpAddress);
            $('#cmdb_domain').val(jsonresult.Domain);

            $('#cmdb_os_family_desc').val(jsonresult.BigFix_OS);
            $('#cmdb_device_class').val(jsonresult.DeviceClass);
            $('#cmdb_segment').val(jsonresult.Segment);

            $('#cmdb_last_reported_date').val(jsonresult.Last_Reported_Date_Text);
            $('#cmdb_last_connected').val(jsonresult.Last_Connected_Text);
            $('#cmdb_summery_role').val(jsonresult.SummaryRole);

            $('#cmdb_server_support_group').val(jsonresult.Server_Support_Group);
            $('#cmdb_risk_bu').val(jsonresult.Risk_BU);
            $('#cmdb_risk_business_line').val(jsonresult.Risk_business_line);

            $('#cmdb_server_risk_bu').val(jsonresult.Server_Risk_BU);
            $('#cmdb_server_risk_bu_manager').val(jsonresult.Server_Risk_BU_Manager);
            // $('#cmdb_').val(jsonresult.);

            $('#cmdb_powershell_version').val(jsonresult.powershellversion);
            $('#cmdb_net_framework_version').val(jsonresult.netframeworkversion);
            $('#cmdb_microsoft_uac_settings').val(jsonresult.microsoftuacsettings);

            $('#cmdb_solution_central_id').val(jsonresult.SolutionCentralID);
            $('#cmdb_solution_central_name').val(jsonresult.SolutionCentralName);
            $('#cmdb_application').val(jsonresult.Application);

            $('#cmdb_beyondtrust_prereq').val(jsonresult.beyondtrustprereq);
            $('#cmdb_beyondtrust_service_status').val(jsonresult.beyondtrustservicestatus);
            $('#cmdb_beyondtrust_version').val(jsonresult.beyondtrustversion);

            $('#cmdb_beyondtrust_console_adapter_version_Server').val(jsonresult.beyondtrustconsoleadapterversionServer);
            $('#cmdb_beyondtrust_console_adapter_service_status_server').val(jsonresult.beyondtrustconsoleadapterservicestatusServer);
            $('#cmdb_microsoft_windows_uac_status').val(jsonresult.microsoftwindowsuacstatus);

            $('#cmdb_microsoft_uac_beyondtrust').val(jsonresult.microsoftuacbeyondtrust);
            $('#cmdb_microsoft_net_release').val(jsonresult.microsoftnetrelease);
            $('#cmdb_beyondtrust_avecto_proxy_conf_server').val(jsonresult.beyondtrustavectoproxyconfserver);

            $('#cmdb_uac_prerequisite').val(jsonresult.UACPrerequisite);
            $('#cmdb_net_prerequisite').val(jsonresult.NetPrerequisite);
            $('#cmdb_beyondtrust_connectivity_prerequisite').val(jsonresult.BeyondTrustConnectivityPrerequisite);

            $('#cmdb_beyondtrust_policy').val(jsonresult.BeyondTrustPolicy);
            $('#cmdb_rsa_connectivity').val(jsonresult.RSAConnectivity);
            // $('#cmdb_').val(jsonresult.);
            // ADGroupsLookupADGroupsTab();
        } else {
            // Add the "Server not found" page
            $('#server_search_result').load('lookupforms/servers/server_not_found.html');
            // Unhide the results section
            $('#server_search_result').removeAttr('hidden');
        }
    });
}
function get_Json(Url, callback) {
    $.getJSON(Url, function (returndata) {
        callback(returndata);
    });
}


function ADGroupsLookupADGroupsTab() {
    // Replace this when making this multi domain functional
    //
    var server_domain = "FNFIS";
    //
    //
    ad_groups_results = null;
    ad_groups_data = null;
    ad_group_data = null;

    // Globals
    {
        var svr_adgroup_card_html;
        var svr_ad_group_member_html;
        var ad_group_members_results;
        var svr_adgroup_card_html_templ;
    }

    // First, get the servers AD groups
    var url = "http://127.0.0.1:8000/Get-ADGroupLike/FNFIS/BEGINSWITH/"
    url = url + $('#server_search_text').val();

    // $.getJSON(url).done(function (ad_groups_results) {
    get_Json(url, function (returndata) {
        ad_groups_results = returndata;

        console.log("*********************************************************************");
        console.log("ad_groups_results.length :" + ad_groups_results.length);
        console.log("*********************************************************************");

        for (let groups_index = 0; groups_index < ad_groups_results.length; ++groups_index) {
            console.log("*********************************************************************");
            console.log("groups_index :" + groups_index);
            console.log("Group Name: " + ad_groups_results[groups_index].SamAccountName);
            console.log("*********************************************************************");
            // Get a copy of the HTML Template
            svr_adgroup_card_html = document.getElementById('svr_ad_group_card_templ').innerHTML;

            console.log("*********************************************************************");
            console.log("groups_index :" + groups_index);
            console.log("svr_adgroup_card_html :" + svr_adgroup_card_html);
            console.log("*********************************************************************");

            // Create the new HTML Element id's
            var group_header2_id = "srv_ad_grp_header_card_header_id_" + groups_index;
            var group_card_body_id = "srv_ad_grp_card_body_id_" + groups_index;
            var group_card_body_accordion_id = "srv_ad_grp_accordion_card_body_id_" + groups_index;
            var srv_ad_grp_owners_id = "srv_ad_grp_owners_id_" + groups_index;
            var srv_ad_grp_rbu_id = "srv_ad_grp_rbu_id_" + groups_index;
            var srv_ad_grp_grp_email_id = "srv_ad_grp_grp_email_id" + groups_index;
            var srv_ad_grp_members_id = "srv_ad_grp_members_id" + groups_index;

            // Set new ids in the template HTML
            svr_adgroup_card_html = svr_adgroup_card_html.replaceAll("{{srv_ad_grp_accordion_card_header}}", group_header2_id);
            svr_adgroup_card_html = svr_adgroup_card_html.replaceAll("{{srv_ad_grp_card_body}}", group_card_body_id);
            svr_adgroup_card_html = svr_adgroup_card_html.replaceAll("{{srv_ad_grp_accordion_card_body_id}}", group_card_body_accordion_id);

            svr_adgroup_card_html = svr_adgroup_card_html.replaceAll("{{srv_ad_grp_owners_id}}", srv_ad_grp_owners_id);
            svr_adgroup_card_html = svr_adgroup_card_html.replaceAll("{{srv_ad_grp_rbu_id}}", srv_ad_grp_rbu_id);
            svr_adgroup_card_html = svr_adgroup_card_html.replaceAll("{{srv_ad_grp_grp_email_id}}", srv_ad_grp_grp_email_id);

            // Get all Group members
            ad_group_members_results = null;
            ad_group_members_data = null;
            ad_group_member_data = null;

            var svr_ad_group_member_html_templ = "<option>{{srv_ad_grp_member}}</option>\n";

            var url = "http://127.0.0.1:8000/Get-ADGroupMember/";
            // Add the Domain: http://127.0.0.1:8000/Get-ADGroupMember/FNFIS/
            url = url + server_domain + "/";
            // Add the Group Name http://127.0.0.1:8000/Get-ADGroupMember/FNFIS/GroupName
            url = url + ad_groups_results[groups_index].SamAccountName;

            get_Json(url, function (returndata) {
                ad_group_members_results = returndata;

                console.log("*********************************************************************");
                console.log("ad_group_members_results.length :" + ad_group_members_results.length);
                console.log("*********************************************************************");
                // $.getJSON(url).done(function (ad_group_members_results) {
                if (ad_group_members_results !== null) {
                    for (let members_index = 0; members_index < ad_group_members_results.length; ++members_index) {
                        // Get the HTML
                        //console.log("*********************************************************************");
                        //console.log("Member index :" + members_index);
                        //console.log("Member Name :" + ad_group_members_results[members_index].SamAccountName);
                        //console.log("ad_group_members_results.length :" + ad_group_members_results.length);

                        if (svr_ad_group_member_html != null) {
                            svr_ad_group_member_html += svr_ad_group_member_html_templ;
                        } else {
                            svr_ad_group_member_html = svr_ad_group_member_html_templ;
                        }
                        // Replace the placeholder "{{srv_ad_grp_member}}" with the member SamAccountName
                        svr_ad_group_member_html = svr_ad_group_member_html.replaceAll("{{srv_ad_grp_member}}", ad_group_members_results[members_index].SamAccountName);
                    }
                    // Now that we have all the options, we can write the HTML to the main HTML String

                    svr_adgroup_card_html = svr_adgroup_card_html.replaceAll("{{srv_ad_grp_members_options_html}}", svr_ad_group_member_html);
                } else {
                    svr_adgroup_card_html = svr_adgroup_card_html.replaceAll("{{srv_ad_grp_members_options_html}}", "<option>No Members</option>\n");
                }

                // Add them to the selection box
                // $("#svr_ad_groups_accordian").find(srv_ad_grp_members_id).val(ad_groups_data[index]['fis-ResourceOwners'])

                // Write the new group HTML template to the page
                // console.log(svr_adgroup_card_html);
                $(svr_adgroup_card_html).appendTo('#ad-groups-accordion-dyn-section');

                // Add the data to the newly loaded HTML elements.

                // JavaScript needs a "#" in front of the id, to know what type of id we're looking for.
                var group_header2_id = "#" + group_header2_id;
                var group_card_body_id = "#" + group_card_body_id;
                var srv_ad_grp_owners_id = "#" + srv_ad_grp_owners_id;
                var srv_ad_grp_rbu_id = "#" + srv_ad_grp_rbu_id;
                var srv_ad_grp_grp_email_id = "#" + srv_ad_grp_grp_email_id;
                var srv_ad_grp_members_id = "#" + srv_ad_grp_members_id

                // Add the group name to the Card Header
                $("#svr_ad_groups_accordian").find(group_header2_id).html(ad_groups_results[groups_index].SamAccountName);

                // Add the Ownership Information to the Cards fields
                $("#svr_ad_groups_accordian").find(srv_ad_grp_owners_id).val(ad_groups_results[groups_index]['fis-ResourceOwners']);
                $("#svr_ad_groups_accordian").find(srv_ad_grp_rbu_id).val(ad_groups_results[groups_index]['fis-L10']);
                $("#svr_ad_groups_accordian").find(srv_ad_grp_grp_email_id).val(ad_groups_results[groups_index]['extensionAttribute1']);

                // Cleanup
                svr_adgroup_card_html = null
                group_header2_id = null
                group_card_body_id = null
                group_card_body_accordion_id = null
                srv_ad_grp_owners_id = null
                srv_ad_grp_rbu_id = null
                srv_ad_grp_grp_email_id = null
                srv_ad_grp_members_id = null



                });
            }

        $('#ad_groups_table').removeAttr('hidden');
    });
}